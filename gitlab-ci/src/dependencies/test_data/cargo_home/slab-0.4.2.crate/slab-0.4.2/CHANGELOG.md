# 0.4.2 (January 11, 2019)

* Add `Slab::drain` (#56).

# 0.4.1 (July 15, 2018)

* Improve `reserve` and `reserve_exact` (#37).
* Implement `Default` for `Slab` (#43).
