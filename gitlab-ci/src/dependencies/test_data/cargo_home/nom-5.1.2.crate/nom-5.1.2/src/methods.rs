//! method combinators

/// do not use: method combinators moved to the nom-methods crate
#[macro_export]
macro_rules! method (
  ($($args:tt)*) => (compile_error!("method combinators moved to the nom-methods crate"););
);

/// do not use: method combinators moved to the nom-methods crate
#[macro_export]
macro_rules! call_m (
  ($($args:tt)*) => (compile_error!("method combinators moved to the nom-methods crate"););
);

/// do not use: method combinators moved to the nom-methods crate
#[macro_export]
macro_rules! apply_m (
  ($($args:tt)*) => (compile_error!("method combinators moved to the nom-methods crate"););
);

